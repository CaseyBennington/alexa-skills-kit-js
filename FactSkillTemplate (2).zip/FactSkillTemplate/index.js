/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

/**
 * This simple sample has no external dependencies or session management, and shows the most basic
 * example of how to create a Lambda function for handling Alexa Skill requests.
 *
 * Examples:
 * One-shot model:
 *  User: "Alexa, ask Euro FUn for a euro fact"
 *  Alexa: "Here's your euro fact: ..."
 */

/**
 * App ID for the skill
 */
var APP_ID = "amzn1.echo-sdk-ams.app.fd4ad53f-ffe6-4589-8409-74a9285b1508"; //replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";

/**
 * Array containing euro facts.
 */
var EURO_FACTS = [
    "For the first time there will be 24 teams participating.",
    "Gibraltar entered qualifications for the very first time.",
    "France beat 2 countries for Euro 2016 hosting rights.",
    "France will host the tournament for a record 3rd time.",
    "Christiano Ronaldo has now scored in 4 different Euros.",
    "The Euro 2016 logo contains the trophy and colours of the French flag.",
    "The Euro 2016 slogan is Le Rendez-Vous.",
    "Super victor is the official Euro 2016 mascot.",
    "Cheapest Euro 2016 tickets will cost €25.",
    "Croatia ended Spain's unbeaten and clean sheet runs.",
    "10 host cities and 10 stadiums will be used for the matches.",
    "Group winners, runners-up, and best four third-placed teams advance to the round of 16.",
    "David Guetta will produce official Euro 2016 song.",
    "2 countries can win the Euro a record of 4 times.",
    "The champions will play the 2017 Confederations Cup."
];

/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * Euro2016FunFacts is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var Euro2016FunFacts = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
Euro2016FunFacts.prototype = Object.create(AlexaSkill.prototype);
Euro2016FunFacts.prototype.constructor = Euro2016FunFacts;

Euro2016FunFacts.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("Euro2016FunFacts onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any initialization logic goes here
};

Euro2016FunFacts.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("Euro2016FunFacts onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    handleNewFactRequest(response);
};

/**
 * Overridden to show that a subclass can override this function to teardown session state.
 */
Euro2016FunFacts.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("Euro2016FunFacts onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any cleanup logic goes here
};

Euro2016FunFacts.prototype.intentHandlers = {
    "GetNewFactIntent": function (intent, session, response) {
        handleNewFactRequest(response);
    },

    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("You can ask Euro 2016 Fun Facts tell me a euro fact, or, you can say exit... What can I help you with?", "What can I help you with?");
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        var speechOutput = "Goodbye";
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        var speechOutput = "Goodbye";
        response.tell(speechOutput);
    }
};

/**
 * Gets a random new fact from the list and returns to the user.
 */
function handleNewFactRequest(response) {
    // Get a random euro fact from the euro facts list
    var factIndex = Math.floor(Math.random() * EURO_FACTS.length);
    var fact = EURO_FACTS[factIndex];

    // Create speech output
    var speechOutput = "Here's your euro fact: " + fact;

    response.tellWithCard(speechOutput, "Euro2016FunFacts", speechOutput);
}

// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    // Create an instance of the Euro2016FunFacts skill.
    var Euro2016FunFacts = new Euro2016FunFacts();
    Euro2016FunFacts.execute(event, context);
};
